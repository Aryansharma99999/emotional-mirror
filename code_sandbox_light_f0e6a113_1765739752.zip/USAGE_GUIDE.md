# 🕯️ Sanctuary - Quick Start Guide

## Welcome to Your Safe Space

This guide will help you get started with Sanctuary in just a few minutes.

---

## 🎯 First Steps

### 1. Choose Your Theme
In the top-right corner, you'll see 4 theme icons:
- 🌙 **Midnight** (Purple-blue, default)
- 🌲 **Forest** (Green earth tones)
- 💧 **Ocean** (Blue water tones)
- 🔥 **Ember** (Warm orange-red tones)

Click any icon to switch themes. Your preference is automatically saved.

---

## 📖 Module Guide

### 🚪 The Dark Room
**When to use:** When you need to express something you can't say anywhere else.

**How to use:**
1. Click "The Dark Room" from the home page
2. Write freely in the black space
3. Toggle "Auto-delete after closing" if you want
4. Click "Hold This" to save or "Clear" to delete
5. **PANIC BUTTON** (top-right ⭕) - Instantly exits to Google

**Pro tip:** Use this for raw, unfiltered thoughts. No one will ever see this.

---

### ✉️ Unsent
**When to use:** When you need to say something to someone but can't actually send it.

**How to use:**
1. Click "Unsent" from home
2. Choose who you're writing to (dropdown menu)
3. Optionally add their name
4. Select your mode: Raw, Honest, or Compassionate
5. Write your letter
6. Click "Hold This" when done

**Pro tip:** Write to your past self about things you wish you could tell them.

---

### 🪞 Emotional Mirror
**When to use:** When you want to feel understood without being fixed or advised.

**How to use:**
1. Click "Emotional Mirror" from home
2. Write about what you're feeling
3. Click "Show Me My Reflection"
4. Read the reflection slowly
5. Save it if it resonates

**What you'll get:**
- A reflection of your emotional state
- Emotion names (not labels)
- Presence statements (no advice)

**Pro tip:** This isn't about fixing. It's about being seen.

---

### 🌫️ Noise → Clarity
**When to use:** When your mind feels chaotic and you need to find "the core."

**How to use:**
1. Click "Noise → Clarity" from home
2. Pour out everything racing through your mind
3. Don't organize—just write
4. Click "Find the Core"
5. Receive your core insight

**What you'll get:**
- The central emotion beneath the noise
- What that emotion often needs
- Gentle guidance (not commands)

**Pro tip:** Write without stopping. Let it be messy.

---

### 🌊 Emotional Tides
**When to use:** To track your emotional patterns over time without pressure or streaks.

**How to use:**
1. Click "Emotional Tides" from home
2. Select how you're feeling right now (5 states)
3. Optionally add a note
4. Click "Record This Moment"
5. Return regularly to see patterns emerge

**What you'll see:**
- A visual timeline of your states
- Pattern insights after 3+ check-ins
- Your most common emotional state

**Pro tip:** Check in once a day. No pressure if you miss days.

---

### 🗜️ Compress & Hold
**When to use:** When you've written too much and need to distill it into something carryable.

**How to use:**
1. Click "Compress & Hold" from home
2. Pour out your thoughts (as many as you need)
3. Watch the word count
4. Click "Compress This"
5. Receive a 3-sentence truth

**What you'll get:**
- Original word count vs compressed
- Core emotion identified
- The essence of what you wrote

**Options after compression:**
- **Hold This** - Save it
- **Let It Dissolve** - Delete immediately
- **Try Again** - Different compression

**Pro tip:** Use this after a long journal entry in Dark Room.

---

## 🔐 Privacy & Safety

### Your Data
✅ Everything stays on YOUR device  
✅ No servers, no uploads, no cloud  
✅ No tracking, no analytics, no cookies  
✅ You can delete entries any time  

### Storage Location
Your data is stored in your browser's localStorage:
- **Chrome/Edge:** Application > Local Storage
- **Firefox:** Storage > Local Storage
- **Safari:** Storage > Local Storage

### Clearing Data
To delete everything:
1. Go to browser settings
2. Clear browsing data
3. Select "Cookies and site data"
4. Or delete individual entries in each module

### Export (Coming Soon)
Future versions will let you export your data as JSON.

---

## ⌨️ Keyboard Shortcuts

- `ESC` - Return to home from any module
- `Ctrl/Cmd + S` - Quick save (Dark Room, Unsent)

---

## 🎨 Design Features

### Animations
Everything moves slowly and gently by intention:
- Fade-ins take 0.8 seconds
- Hover effects are subtle
- No sudden movements

### Accessibility
- High contrast text
- Focus indicators for keyboard navigation
- Semantic HTML structure
- Screen reader compatible

### Mobile
Sanctuary works beautifully on mobile devices:
- Responsive layout
- Touch-friendly buttons
- Optimized text sizes

---

## 💡 Tips for Best Experience

### 1. Make It Routine
Check in with Emotional Tides daily. Patterns emerge with consistency.

### 2. Start with Dark Room
If you're new, begin here. Get comfortable with the space.

### 3. Don't Force It
If a module doesn't resonate, skip it. Use what helps.

### 4. Be Messy
Your entries don't need to be "good." They need to be real.

### 5. Trust the Reflections
The Emotional Mirror isn't perfect, but it tries to see you without fixing you.

### 6. Use Unsent for Closure
Writing what you can't send creates closure without consequence.

### 7. Compress When Overwhelmed
Turn pages of chaos into sentences of truth.

---

## 🚨 When to Seek Professional Help

Sanctuary is NOT therapy. Please reach out if you're experiencing:

- **Suicidal thoughts** → 988 (US) or text HOME to 741741
- **Severe depression or anxiety** → Contact a mental health professional
- **Crisis situations** → Local emergency services
- **Trauma needing professional support** → Find a licensed therapist

**Resources:**
- National Suicide Prevention Lifeline: 988
- Crisis Text Line: Text HOME to 741741
- SAMHSA Hotline: 1-800-662-4357
- International Crisis Lines: https://www.iasp.info/resources/Crisis_Centres/

---

## 🐛 Troubleshooting

### Module Won't Load
- **Solution:** Refresh the page (F5)
- Check browser console for errors

### Entries Not Saving
- **Solution:** Make sure localStorage is enabled
- Try a different browser
- Check available storage space

### Theme Won't Switch
- **Solution:** Hard refresh (Ctrl + Shift + R)
- Clear cache if needed

### Panic Button Not Working
- **Solution:** This is a critical feature. Test it immediately after loading.
- If broken, please report it (though it's a simple redirect)

---

## 📱 Installing on Mobile (PWA - Coming Soon)

Future versions will support installation as a mobile app:
1. Visit the site in mobile browser
2. Tap "Add to Home Screen"
3. Launch like any other app
4. Works offline

---

## 🤝 Share Responsibly

If you share Sanctuary with others:
- ✅ Share the values: privacy, compassion, no fixing
- ✅ Emphasize it's NOT therapy
- ✅ Respect that it may not work for everyone
- ❌ Don't pressure people to use it
- ❌ Don't promise it will "fix" them

---

## 💭 Philosophy Reminder

> *"You're not broken. You're human. This is your space."*

Sanctuary exists to:
- **Hold** your thoughts, not solve them
- **Reflect** your feelings, not change them
- **Witness** your patterns, not judge them
- **Respect** your privacy, always

---

## 📬 Questions?

Since this is a static app with no backend, there's no direct support. However:

1. Read the README.md for technical details
2. Check the code (it's all visible)
3. Modify it for your needs (it's open source)
4. Trust the process—the app is designed to be intuitive

---

## 🕯️ A Final Note

Take your time. Nothing here is urgent. Your feelings don't have deadlines.

**Welcome to your safe space.**

---

*Built with intention. Used with compassion.*