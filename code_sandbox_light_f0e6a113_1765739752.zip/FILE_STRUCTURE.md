# 📁 Sanctuary - Complete File Structure

## Project Organization

```
sanctuary/
│
├── 📱 APPLICATION FILES
│   ├── index.html                      # Main application entry point (15KB)
│   │                                   # → Open this to use Sanctuary
│   │
│   ├── css/
│   │   └── style.css                  # Complete styling system (20KB)
│   │                                   # → 4 themes, animations, responsive design
│   │
│   └── js/
│       ├── main.js                    # Core application logic (28KB)
│       │                               # → Navigation, storage, UI interactions
│       │
│       └── emotional-engine.js         # Emotional intelligence system (13KB)
│                                       # → Emotion detection, reflection generation
│
├── 📚 DOCUMENTATION FILES
│   ├── START_HERE.md                  # ⭐ Entry point for new users (9KB)
│   │                                   # → Read this first!
│   │
│   ├── README.md                      # Complete project documentation (11KB)
│   │                                   # → Philosophy, features, technical details
│   │
│   ├── USAGE_GUIDE.md                 # User instructions (8KB)
│   │                                   # → How to use each module
│   │
│   ├── PROJECT_SUMMARY.md             # Technical overview (13KB)
│   │                                   # → For developers and portfolio
│   │
│   ├── DEPLOYMENT.md                  # Hosting guide (9KB)
│   │                                   # → Deploy to web platforms
│   │
│   ├── CHANGELOG.md                   # Version history (7KB)
│   │                                   # → Features, roadmap, known issues
│   │
│   └── FILE_STRUCTURE.md              # This file (you are here)
│                                       # → Visual project organization
│
└── 📊 PROJECT STATS
    Total Files: 11
    Total Size: ~115KB
    Dependencies: 0 (just CDN fonts/icons)
    Build Process: None needed
    Backend: Not required
```

---

## 📱 Application Files Explained

### `index.html` (15KB)
**Purpose:** Main application structure and all 6 modules

**Contains:**
- Home page with module grid
- The Dark Room module
- Unsent module
- Emotional Mirror module
- Noise → Clarity module
- Emotional Tides module
- Compress & Hold module
- Theme selector
- Privacy indicator
- Loading overlay

**Key sections:**
```html
<body>
  ├── Theme selector (top-right)
  ├── Privacy indicator
  ├── Main container
  │   ├── Home page (6 module cards)
  │   ├── Dark Room page
  │   ├── Unsent page
  │   ├── Mirror page
  │   ├── Clarity page
  │   ├── Tides page
  │   └── Compress page
  └── Loading overlay
</body>
```

**Dependencies:**
- Google Fonts (Inter, Merriweather)
- Font Awesome icons
- style.css
- main.js
- emotional-engine.js

---

### `css/style.css` (20KB)
**Purpose:** Complete styling system with themes and animations

**Contains:**
- CSS variables for 4 themes
- Reset and base styles
- Typography system
- Theme selector styles
- Module layouts
- Form elements
- Animations
- Responsive breakpoints
- Accessibility features

**Structure:**
```css
/* Variables - Theme definitions */
:root { ... }
[data-theme="forest"] { ... }
[data-theme="ocean"] { ... }
[data-theme="ember"] { ... }

/* Base styles */
Reset, typography, layout

/* Components */
Buttons, forms, cards, modules

/* Animations */
Fade-ins, slide-ups, floats

/* Responsive */
Mobile breakpoints

/* Accessibility */
Focus states, reduced motion
```

**Themes:**
- Midnight (default): Purple-blue
- Forest: Green earth tones
- Ocean: Blue water tones
- Ember: Warm orange-red

---

### `js/main.js` (28KB)
**Purpose:** Core application logic and UI management

**Contains:**
- Storage manager (localStorage wrapper)
- Navigation system
- Theme management
- Module-specific functions:
  - Dark Room operations
  - Unsent message handling
  - Mirror reflection display
  - Clarity insight processing
  - Tides tracking and visualization
  - Compression algorithm execution
- Entry card creation
- Notification system
- Loading states
- Keyboard shortcuts

**Key functions:**
```javascript
// Storage
StorageManager.get()
StorageManager.set()
StorageManager.remove()

// Navigation
goHome()
showPage()

// Modules
saveDarkRoom()
saveUnsent()
getMirrorReflection()
getClarityInsight()
saveCheckIn()
compressEmotion()

// UI
showLoading()
showNotification()
createEntryCard()
```

---

### `js/emotional-engine.js` (13KB)
**Purpose:** Emotional intelligence and pattern recognition

**Contains:**
- Emotion keyword database (10 emotions)
- Reflection templates (40+ phrases)
- Presence statements
- Emotion detection algorithm
- Reflection generation logic
- Clarity insight extraction
- Compression algorithm
- Pattern analysis
- Utility functions

**Key functions:**
```javascript
EmotionalEngine.detectEmotions(text)
EmotionalEngine.generateReflection(text)
EmotionalEngine.generateClarity(text)
EmotionalEngine.compressEmotion(text)
EmotionalEngine.analyzePattern(checkIns)
```

**Emotion categories:**
- Fear, Anger, Sadness, Loneliness
- Guilt, Overwhelm, Confusion
- Hope, Relief, Avoidance

---

## 📚 Documentation Files Explained

### `START_HERE.md` ⭐ (9KB)
**Purpose:** Entry point for new users

**Read this if:**
- You're new to the project
- You want quick navigation
- You need a roadmap
- You want to know where to start

**Contains:**
- Quick start guide
- Documentation roadmap
- What to do first
- Common questions
- Success checklist

---

### `README.md` (11KB)
**Purpose:** Complete project overview

**Read this if:**
- You want to understand the philosophy
- You need technical details
- You're researching the project
- You want to know all features

**Contains:**
- Purpose and philosophy
- All 6 modules explained
- Design features
- Privacy architecture
- Technical stack
- Roadmap
- Contributing guidelines

---

### `USAGE_GUIDE.md` (8KB)
**Purpose:** User instructions for each module

**Read this if:**
- You want to learn how to use Sanctuary
- You need module-specific tips
- You have questions about features
- You want pro tips

**Contains:**
- First steps
- Module-by-module guide
- Privacy & safety info
- Keyboard shortcuts
- Troubleshooting
- Crisis resources

---

### `PROJECT_SUMMARY.md` (13KB)
**Purpose:** Technical overview and developer info

**Read this if:**
- You're a developer
- You want technical metrics
- You're adding to portfolio
- You want to understand architecture

**Contains:**
- What's included
- Technical features
- Code statistics
- Learning outcomes
- Enhancement ideas
- Interview talking points

---

### `DEPLOYMENT.md` (9KB)
**Purpose:** Hosting and deployment instructions

**Read this if:**
- You want to deploy to the web
- You need hosting options
- You're setting up custom domain
- You want performance tips

**Contains:**
- Local use instructions
- Static hosting options (GitHub, Netlify, Vercel)
- Custom domain setup
- Security best practices
- PWA preparation

---

### `CHANGELOG.md` (7KB)
**Purpose:** Version history and roadmap

**Read this if:**
- You want to see what's implemented
- You're curious about future features
- You want to contribute
- You need version history

**Contains:**
- V1.0.0 features (complete list)
- Future roadmap (V1.1, V2.0, V3.0)
- Known issues
- Technical decisions
- Contributing guidelines

---

### `FILE_STRUCTURE.md` (This File)
**Purpose:** Visual project organization

**Read this if:**
- You want to understand file structure
- You're navigating the codebase
- You need a reference
- You're learning the architecture

---

## 🎯 Which Files Do You Need?

### For Using the App:
**Essential:**
- `index.html` ← Open this
- `css/style.css`
- `js/main.js`
- `js/emotional-engine.js`

**Recommended:**
- `USAGE_GUIDE.md` ← Instructions

**Optional:**
- All other documentation

---

### For Understanding the Project:
**Essential:**
- `START_HERE.md` ← Start here
- `README.md`

**Recommended:**
- `PROJECT_SUMMARY.md`
- `USAGE_GUIDE.md`

**Optional:**
- `CHANGELOG.md`
- `FILE_STRUCTURE.md`

---

### For Deploying:
**Essential:**
- All application files (HTML, CSS, JS)
- `DEPLOYMENT.md` ← Instructions

**Recommended:**
- `README.md` (to include on deployment)
- `USAGE_GUIDE.md` (for users)

**Optional:**
- Other documentation

---

### For Development:
**Essential:**
- All files (to understand full system)
- `PROJECT_SUMMARY.md`
- `CHANGELOG.md`

**Recommended:**
- `FILE_STRUCTURE.md` (this file)
- `README.md`

---

## 🗂️ Logical Groupings

### Core Application
```
index.html
css/style.css
js/main.js
js/emotional-engine.js
```
**Purpose:** The actual working application  
**Total:** 76KB

---

### User Documentation
```
START_HERE.md      ← Entry point
USAGE_GUIDE.md     ← How to use
README.md          ← What it is
```
**Purpose:** Help users understand and use Sanctuary  
**Total:** 28KB

---

### Developer Documentation
```
PROJECT_SUMMARY.md  ← Technical details
DEPLOYMENT.md       ← How to deploy
CHANGELOG.md        ← Version history
FILE_STRUCTURE.md   ← This file
```
**Purpose:** Help developers work with the codebase  
**Total:** 38KB

---

## 📊 File Statistics

| File                     | Size  | Lines | Purpose                    |
|--------------------------|-------|-------|----------------------------|
| index.html               | 15KB  | ~400  | Application structure      |
| css/style.css            | 20KB  | ~900  | Styling + themes           |
| js/main.js               | 28KB  | ~850  | Core logic                 |
| js/emotional-engine.js   | 13KB  | ~350  | Emotion intelligence       |
| **App Subtotal**         | **76KB** | **~2,500** | **Working application** |
| START_HERE.md            | 9KB   | ~350  | Entry point                |
| USAGE_GUIDE.md           | 8KB   | ~300  | User instructions          |
| PROJECT_SUMMARY.md       | 13KB  | ~450  | Technical overview         |
| DEPLOYMENT.md            | 9KB   | ~350  | Hosting guide              |
| CHANGELOG.md             | 7KB   | ~250  | Version history            |
| README.md                | 11KB  | ~400  | Complete documentation     |
| FILE_STRUCTURE.md        | 5KB   | ~200  | This file                  |
| **Docs Subtotal**        | **62KB** | **~2,300** | **Documentation**       |
| **TOTAL**                | **138KB** | **~4,800** | **Complete project**    |

---

## 🚀 Dependency Tree

```
index.html
├── Links to: css/style.css
├── Links to: js/main.js
│   └── Imports: (none - vanilla JS)
└── Links to: js/emotional-engine.js
    └── Imports: (none - vanilla JS)

External (CDN):
├── Google Fonts
│   ├── Inter (300-700 weights)
│   └── Merriweather (300-400 weights)
└── Font Awesome 6.4.0
    └── Icons
```

**Total dependencies: 0** (all external resources via CDN)

---

## 🎨 Code Organization

### HTML Structure:
```
Semantic HTML5
├── Header elements
├── Main content areas
├── Form elements
├── Navigation
└── Interactive components
```

### CSS Organization:
```
Variables (themes)
├── Reset
├── Base styles
├── Typography
├── Layout
├── Components
├── Animations
├── Responsive
└── Accessibility
```

### JavaScript Architecture:
```
StorageManager (data persistence)
├── Module functions (6 modules)
├── UI functions (notifications, loading)
├── Utility functions (formatting, helpers)
└── EmotionalEngine (separate file)
    ├── Detection algorithms
    ├── Generation logic
    └── Analysis functions
```

---

## 💡 Navigation Tips

### Finding Specific Information:

| Want to know...                      | Check this file           |
|--------------------------------------|---------------------------|
| Where to start                       | START_HERE.md             |
| How to use a module                  | USAGE_GUIDE.md            |
| What the philosophy is               | README.md                 |
| How to deploy                        | DEPLOYMENT.md             |
| What's been built                    | CHANGELOG.md              |
| Technical details                    | PROJECT_SUMMARY.md        |
| File organization                    | FILE_STRUCTURE.md (here)  |
| How emotion detection works          | js/emotional-engine.js    |
| How storage works                    | js/main.js (StorageManager)|
| Theme variables                      | css/style.css (top)       |

---

## 🔍 Quick Reference

### Main Entry Points:
- **Use the app:** Open `index.html`
- **Learn to use it:** Read `USAGE_GUIDE.md`
- **Understand it:** Read `README.md`
- **Deploy it:** Read `DEPLOYMENT.md`
- **Extend it:** Read code files (well commented)

### Key Functions (main.js):
- `showPage(name)` - Navigate between modules
- `StorageManager.set(key, value)` - Save data
- `StorageManager.get(key)` - Load data
- `showNotification(message)` - Show toast

### Key Functions (emotional-engine.js):
- `detectEmotions(text)` - Find emotions in text
- `generateReflection(text)` - Create mirror response
- `generateClarity(text)` - Find core insight
- `compressEmotion(text)` - Compress to essence

---

## 🎯 Clean Code Principles Used

1. **Separation of Concerns**
   - HTML (structure)
   - CSS (presentation)
   - JS (behavior)

2. **Single Responsibility**
   - Each function does one thing
   - Modules are independent

3. **DRY (Don't Repeat Yourself)**
   - Reusable functions
   - CSS variables for themes
   - Shared utilities

4. **Clear Naming**
   - Descriptive function names
   - Semantic HTML classes
   - Meaningful variable names

5. **Comments**
   - Every major section
   - Complex logic explained
   - Purpose documented

---

## 🕯️ Final Note

This file structure is intentionally simple:
- **No build process** to configure
- **No node_modules** to manage
- **No framework complexity** to navigate
- **Just files** you can read and understand

Everything is where you'd expect it to be.

---

**Need help navigating? Start with [START_HERE.md](START_HERE.md)**