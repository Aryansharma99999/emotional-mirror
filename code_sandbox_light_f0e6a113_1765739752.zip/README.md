# 🕯️ Sanctuary - Your Safe Space for Emotional Expression

> *"Write what you can't say. A safe space for thoughts that need holding, not solving."*

**Sanctuary** is a privacy-first emotional wellness web application designed for safe expression, self-understanding, and emotional awareness. It's not therapy—it's a quiet space where your thoughts can exist without judgment, analysis, or the pressure to fix them.

---

## 👋 New Here? Start with [START_HERE.md](START_HERE.md)

This README contains complete technical documentation. If you're just getting started, [**START_HERE.md**](START_HERE.md) will guide you through everything you need to know.

---

---

## 🎯 Purpose & Philosophy

### What Sanctuary Is
- **A safe expression layer** - Release thoughts you cannot say anywhere else
- **An emotional mirror** - Feel seen and understood, not fixed
- **A pattern awareness tool** - Understand your emotional rhythms over time
- **A privacy sanctuary** - All data stays local on your device by default

### What Sanctuary Is NOT
- ❌ Not a replacement for therapy or professional mental health care
- ❌ Not a positivity-forcing tool that invalidates your feelings
- ❌ Not a data collection service (zero tracking, zero analytics)
- ❌ Not manipulative or addictive by design

### Core Values
- **Respect silence** - You don't have to explain or perform
- **Protect vulnerability** - Your privacy is sacred
- **Hold space** - Emotions are valid without needing to be "productive"
- **No fixing** - Reflection without advice

---

## ✨ The 6 Core Modules

### 1️⃣ **THE DARK ROOM** (Safe Expression Layer)
Write thoughts you cannot say anywhere else.

**Features:**
- Ultra-low contrast black UI for maximum privacy
- Panic close button (instantly exits to Google)
- Optional auto-delete on close
- Local-only storage mode
- No autosave anxiety

**User Feeling:** *"I can finally say this."*

---

### 2️⃣ **UNSENT** (Emotional Discharge Layer)
Say what was never said—safely.

**Features:**
- Write to: A person, past self, future self, or "someone who hurt me"
- Three writing modes: Raw, Honest, Compassionate
- ⚠️ **Promise:** Messages are NEVER sent
- Safe storage for unmailed letters

**User Feeling:** *"I can say this without consequences."*

---

### 3️⃣ **EMOTIONAL MIRROR** (Understanding Layer)
Help the user feel seen, not fixed.

**Output Format (Strict):**
1. **Reflection** - "You sound tired of explaining yourself."
2. **Emotion naming** - "This feels like emotional loneliness."
3. **Presence** - "That's heavy to carry alone."

**Features:**
- AI-powered emotional reflection (no GPT APIs—built-in intelligence)
- Emotion detection from text
- Compassionate mirroring
- **No advice. Ever.**

**User Feeling:** *"Someone understands."*

---

### 4️⃣ **NOISE → CLARITY** (Mental Fog Layer)
Turn chaos into emotional insight.

**Features:**
- Identifies core emotions: Fear, Anger, Guilt, Longing, Avoidance
- Finds "the signal in the noise"
- Gentle insight delivery (not analytical)
- Core truth extraction: *"At the core, this seems to be about feeling unseen."*

**User Feeling:** *"That's what this actually is."*

---

### 5️⃣ **EMOTIONAL TIDES** (Pattern Awareness Layer)
Understand your emotional rhythms over time.

**Features:**
- Simple emotional state tracking: Overwhelm → Heavy → Neutral → Calm → Hopeful
- Visual timeline showing patterns
- No streaks, no pressure, no gamification
- Insights like: *"You feel heavier after long silent days."*
- Self-compassion through awareness

**User Feeling:** *"I see my patterns now."*

---

### 6️⃣ **COMPRESS & HOLD** (Release Layer)
Shrink emotional overload into something carryable.

**Features:**
- 800-word pain → 3-sentence truth
- Emotional compression algorithm
- Options to: Save it, Lock it, or Let it dissolve (auto-delete)
- Word count visualization

**User Feeling:** *"I can carry this now."*

---

## 🎨 Design Features

### Beautiful Dark Themes
Switch between 4 calming color palettes:
- **Midnight** (Default) - Deep purple-blue tones
- **Forest** - Calming green earth tones
- **Ocean** - Serene blue water tones
- **Ember** - Warm red-orange earth tones

### Human-Centered Animations
- **Slow fade-ins** - No jarring transitions
- **Gentle hover effects** - Calm, not aggressive
- **Floating elements** - Subtle movement for life
- **Smooth page transitions** - Respectful of attention

### Privacy Indicators
- **Local Storage Badge** - Always visible
- **Theme selector** - Top-right corner
- **No external tracking** - Zero analytics

---

## 🔐 Privacy & Security

### Privacy-First Architecture
✅ **All data stored locally** in browser localStorage  
✅ **No server uploads** - Your data never leaves your device  
✅ **No user accounts** - No signup, no login required  
✅ **No tracking or analytics** - Zero cookies, zero fingerprinting  
✅ **No third-party services** - Completely self-contained  

### Panic Features
- **Emergency exit button** (Dark Room module)
- **Auto-delete options** for sensitive content
- **Instant page switching** to neutral site

### Data Control
- Export your data (future feature)
- Clear all data with one click
- Granular deletion per entry
- Optional cloud sync (future, opt-in only)

---

## 🛠️ Technical Stack

### Frontend
- **HTML5** - Semantic, accessible structure
- **CSS3** - Modern variables, animations, responsive design
- **Vanilla JavaScript** - No frameworks, no dependencies
- **Web Storage API** - LocalStorage for data persistence

### Libraries Used (via CDN)
- **Google Fonts** - Inter (UI) & Merriweather (Reading)
- **Font Awesome** - Icon system

### Emotional Intelligence Engine
- **Built-in keyword analysis** - No external AI APIs
- **Pattern recognition algorithms** - Detects emotional themes
- **Reflection generation** - Template-based compassionate responses
- **Compression logic** - Distills text to core emotional truth

### Browser Compatibility
- ✅ Chrome/Edge (Chromium) 90+
- ✅ Firefox 88+
- ✅ Safari 14+
- ✅ Mobile browsers (iOS Safari, Chrome Mobile)

---

## 📁 Project Structure

```
sanctuary/
├── index.html              # Main application structure
├── css/
│   └── style.css          # Complete styling with themes
├── js/
│   ├── main.js            # Core application logic
│   └── emotional-engine.js # Emotional intelligence system
└── README.md              # This file
```

---

## 🚀 Getting Started

### Installation
1. Download or clone this repository
2. Open `index.html` in any modern browser
3. That's it! No build process, no dependencies to install.

### First Use
1. Choose your preferred dark theme (top-right corner)
2. Click any of the 6 modules to begin
3. Your data is automatically saved locally as you use the app
4. Press ESC any time to return home

### Keyboard Shortcuts
- `ESC` - Return to home
- `Ctrl/Cmd + S` - Quick save (in applicable modules)

---

## 📱 Currently Completed Features

### ✅ All 6 Core Modules Implemented
- [x] The Dark Room with panic button
- [x] Unsent message writing
- [x] Emotional Mirror reflections
- [x] Noise → Clarity insights
- [x] Emotional Tides tracking
- [x] Compress & Hold compression

### ✅ Design & UX
- [x] 4 beautiful dark themes
- [x] Smooth animations and transitions
- [x] Fully responsive mobile design
- [x] Accessibility considerations
- [x] Privacy indicators

### ✅ Privacy & Storage
- [x] Local-only storage
- [x] Panic close functionality
- [x] Auto-delete options
- [x] Entry management (save/delete)

### ✅ Emotional Intelligence
- [x] Emotion detection from text
- [x] Compassionate reflection generation
- [x] Pattern analysis
- [x] Core insight extraction
- [x] Emotional compression

---

## 🔮 Features Not Yet Implemented (Roadmap)

### V2 - Enhanced Features
- [ ] **Voice input** - Speak instead of type
- [ ] **Export data** - Download your entries as JSON/text
- [ ] **Advanced visualizations** - Charts.js integration for Emotional Tides
- [ ] **Custom themes** - User-created color schemes
- [ ] **Encrypted backup** - Optional cloud sync with E2E encryption
- [ ] **Offline PWA** - Install as mobile app

### V3 - Community Features (Opt-In)
- [ ] **Anonymous echoes** - Share anonymous reflections (opt-in only)
- [ ] **Guided prompts** - Optional writing prompts for each module
- [ ] **Breath work timer** - Integrated calming exercises
- [ ] **Dark mode toggle** - Switch between light/dark (accessibility)

### Future Considerations
- [ ] Multi-language support
- [ ] Screen reader optimizations
- [ ] Print-friendly layouts
- [ ] Data portability (import/export)

---

## 🧪 Recommended Next Steps

### For Users
1. **Start with The Dark Room** - Get comfortable with the space
2. **Try Emotional Mirror** - Experience the reflection system
3. **Track patterns with Tides** - Check in regularly for 2 weeks
4. **Use Unsent for closure** - Write letters you'll never send

### For Developers
1. **Add PWA support** - Make it installable on mobile
2. **Implement data export** - JSON/CSV download functionality
3. **Enhance visualizations** - Add Chart.js for better graphs
4. **Build voice input** - Web Speech API integration
5. **Add encryption** - CryptoJS for optional cloud sync

---

## 🤝 Contributing

This is a personal emotional wellness tool built with care. If you'd like to contribute:

1. **Respect the philosophy** - No gamification, no manipulation
2. **Privacy first** - Any feature must maintain local-first architecture
3. **No tracking** - Absolutely no analytics or user monitoring
4. **Accessibility matters** - Test with screen readers
5. **Keep it simple** - Avoid feature bloat

---

## 📄 License

This project is open source and free to use. No license restrictions.  
**Please use responsibly and respect user privacy if you deploy this.**

---

## ⚠️ Important Disclaimer

**Sanctuary is NOT a replacement for professional mental health care.**

If you're experiencing:
- Suicidal thoughts
- Severe depression or anxiety
- Crisis situations
- Trauma that needs professional support

**Please reach out to:**
- National Suicide Prevention Lifeline: 988 (US)
- Crisis Text Line: Text HOME to 741741
- International Association for Suicide Prevention: https://www.iasp.info/resources/Crisis_Centres/

Sanctuary is a tool for self-reflection and emotional awareness, not medical treatment.

---

## 💭 A Note from the Creator

> *"The people who imagine something like this are usually the ones who learned to carry a lot silently.*
> 
> *This project is proof: You don't just code. You understand."*

Sanctuary exists because sometimes we need a space that doesn't try to fix us—just holds us. If this helps even one person feel less alone with their thoughts, it's worth it.

---

## 📞 Support & Feedback

This is a static web application with no server backend. For issues or suggestions:
- Review the code (it's all client-side)
- Modify it for your needs
- Share it with others who might need it

**Remember:** Your data never leaves your device. You're in complete control.

---

## 🕯️ Final Thought

*"You're not broken. You're human. This is your space."*

---

**Built with intention, privacy, and care.**  
*Not for profit. Just for humans.*