# 🚀 Sanctuary - Deployment Guide

This guide explains how to deploy Sanctuary to various platforms.

---

## 🎯 Deployment Options

Sanctuary is a **100% static website** with no backend or build process. This makes deployment incredibly simple.

---

## ✅ Option 1: Local Use (Recommended for Privacy)

### For Personal Use:
1. Download all files to your computer
2. Open `index.html` in any modern browser
3. Bookmark it for easy access
4. **Your data stays only on this device**

### Advantages:
- ✅ Maximum privacy (never leaves your computer)
- ✅ Works offline
- ✅ No hosting costs
- ✅ Complete control

### To Share Locally:
- Copy the entire folder to a USB drive
- Share via file sharing (not cloud)
- Each person's data stays separate

---

## 🌐 Option 2: Static Hosting Services

### GitHub Pages (Free)

**Steps:**
1. Create a GitHub repository
2. Upload all files to the repository
3. Go to Settings > Pages
4. Select branch (usually `main`) and root directory
5. Save and wait 2-3 minutes
6. Access at: `https://yourusername.github.io/sanctuary/`

**Advantages:**
- ✅ Free hosting
- ✅ HTTPS by default
- ✅ Easy updates via Git
- ✅ No ads

**Privacy Note:** GitHub will see the files, but not user data (stored locally in browser).

---

### Netlify (Free)

**Steps:**
1. Sign up at netlify.com
2. Drag and drop the entire folder
3. Get instant deployment
4. Custom domain available

**Command Line (Netlify CLI):**
```bash
npm install -g netlify-cli
netlify deploy --dir=. --prod
```

**Advantages:**
- ✅ Instant deployment
- ✅ Automatic HTTPS
- ✅ Free SSL certificate
- ✅ CDN included

---

### Vercel (Free)

**Steps:**
1. Sign up at vercel.com
2. Import from GitHub or upload files
3. Deploy with one click
4. Get auto-generated URL

**Command Line:**
```bash
npm install -g vercel
vercel
```

**Advantages:**
- ✅ Lightning fast
- ✅ Global CDN
- ✅ Zero config
- ✅ Preview deployments

---

### Cloudflare Pages (Free)

**Steps:**
1. Sign up at pages.cloudflare.com
2. Connect GitHub or upload directly
3. Deploy instantly
4. Free unlimited bandwidth

**Advantages:**
- ✅ Excellent performance
- ✅ DDoS protection
- ✅ Analytics (optional)
- ✅ Custom domains

---

## 📱 Option 3: Self-Hosting

### Simple HTTP Server (Python)

**Steps:**
1. Open terminal in the project folder
2. Run:
   ```bash
   # Python 3
   python -m http.server 8080
   
   # Python 2
   python -m SimpleHTTPServer 8080
   ```
3. Visit: `http://localhost:8080`

**For Network Access:**
```bash
python -m http.server 8080 --bind 0.0.0.0
```
Then access from other devices: `http://YOUR_IP:8080`

---

### Node.js Server

**Using `http-server`:**
```bash
npm install -g http-server
http-server -p 8080
```

**Using `serve`:**
```bash
npm install -g serve
serve -s . -p 8080
```

---

### Apache/Nginx

**Apache (.htaccess):**
```apache
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteBase /
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteRule . /index.html [L]
</IfModule>
```

**Nginx (nginx.conf):**
```nginx
server {
    listen 80;
    server_name sanctuary.example.com;
    root /path/to/sanctuary;
    index index.html;
    
    location / {
        try_files $uri $uri/ /index.html;
    }
}
```

---

## 🔐 Privacy Considerations

### Before Deploying Publicly:

1. **Understand the Privacy Model:**
   - User data stays in their browser (localStorage)
   - No data sent to server
   - But hosting provider can see the source code

2. **HTTPS is Essential:**
   - localStorage only works securely over HTTPS
   - All modern hosts provide free SSL
   - Never deploy without HTTPS

3. **No Analytics:**
   - Do NOT add Google Analytics
   - Do NOT add tracking scripts
   - This breaks the trust promise

4. **Respect the Philosophy:**
   - Keep the app local-first
   - Don't modify to collect data
   - Maintain the no-tracking promise

---

## 📋 Pre-Deployment Checklist

- [ ] Test all 6 modules work correctly
- [ ] Verify theme switching works
- [ ] Test on mobile devices
- [ ] Check localStorage saves/loads
- [ ] Test panic button (Dark Room)
- [ ] Verify keyboard shortcuts (ESC, Ctrl+S)
- [ ] Test all entry save/delete functions
- [ ] Check responsive design on small screens
- [ ] Verify no console errors
- [ ] Test with different browsers:
  - [ ] Chrome/Edge
  - [ ] Firefox
  - [ ] Safari
  - [ ] Mobile Safari
  - [ ] Chrome Mobile

---

## 🌍 Custom Domain Setup

### After Deploying:

**GitHub Pages:**
1. Add CNAME file with your domain
2. Update DNS with A records to GitHub IPs
3. Enable HTTPS in repository settings

**Netlify/Vercel/Cloudflare:**
1. Add custom domain in dashboard
2. Update DNS nameservers or records
3. SSL automatically provisions

**Example DNS Setup:**
```
Type    Name    Value
A       @       [hosting IP]
CNAME   www     yourdomain.com
```

---

## 🔄 Updating After Deployment

### GitHub Pages:
```bash
git add .
git commit -m "Update Sanctuary"
git push origin main
```

### Netlify/Vercel:
- Push to GitHub (auto-deploys)
- Or drag-drop new files

### Manual Hosting:
- Replace files on server
- Clear CDN cache if applicable

---

## 📊 Performance Optimization

### Already Optimized:
- ✅ No build process needed
- ✅ Minimal dependencies (just fonts + icons)
- ✅ Vanilla JS (no framework overhead)
- ✅ CSS variables for themes (no duplication)

### Optional Enhancements:
1. **Compress Images** (if you add custom assets)
2. **Minify CSS/JS** (not critical, files are small)
3. **Enable Gzip** on server
4. **Add Service Worker** for offline (future)

---

## 🐛 Troubleshooting Deployment

### Issue: CSS/JS Not Loading
**Solution:** Check file paths are relative, not absolute

### Issue: localStorage Not Working
**Solution:** Must be served over HTTPS (not http://)

### Issue: Fonts Not Loading
**Solution:** Google Fonts CDN may be blocked. Host locally if needed.

### Issue: Theme Not Persisting
**Solution:** Check browser allows localStorage (not in private mode)

---

## 🚨 Security Best Practices

1. **Use HTTPS Always**
   - Required for localStorage to work properly
   - All free hosts provide SSL

2. **No Backend Needed**
   - Don't add a server "just because"
   - Keep it static for maximum security

3. **Content Security Policy** (Optional):
```html
<meta http-equiv="Content-Security-Policy" 
      content="default-src 'self'; 
               style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; 
               font-src 'self' https://fonts.gstatic.com https://cdn.jsdelivr.net;
               script-src 'self' 'unsafe-inline';">
```

4. **Privacy Headers** (if using custom server):
```
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Referrer-Policy: no-referrer
Permissions-Policy: geolocation=(), microphone=(), camera=()
```

---

## 📱 PWA Deployment (Future)

### To Make It Installable:

1. **Create manifest.json:**
```json
{
  "name": "Sanctuary",
  "short_name": "Sanctuary",
  "description": "Your safe space for emotional expression",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#0a0a0f",
  "theme_color": "#7c7cf5",
  "icons": [
    {
      "src": "/icon-192.png",
      "sizes": "192x192",
      "type": "image/png"
    },
    {
      "src": "/icon-512.png",
      "sizes": "512x512",
      "type": "image/png"
    }
  ]
}
```

2. **Add Service Worker:**
```javascript
// sw.js
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open('sanctuary-v1').then((cache) => {
      return cache.addAll([
        '/',
        '/index.html',
        '/css/style.css',
        '/js/main.js',
        '/js/emotional-engine.js'
      ]);
    })
  );
});
```

3. **Register in HTML:**
```javascript
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/sw.js');
}
```

---

## 🎯 Recommended Deployment

**For Personal Use:**
- Just open `index.html` locally
- No hosting needed

**For Sharing with Friends:**
- GitHub Pages (free + easy)

**For Public Access:**
- Netlify or Vercel (best performance)
- Cloudflare Pages (best security)

**For Organizations:**
- Self-host on your own server
- Full control over infrastructure

---

## 📞 Post-Deployment

### Share Responsibly:
- ✅ Emphasize it's NOT therapy
- ✅ Include crisis resources
- ✅ Respect privacy (don't force usage)
- ✅ Make disclaimer visible

### Monitor (Without Tracking):
- Check if site is accessible
- Verify HTTPS is working
- Test periodically
- **Do NOT add user analytics**

---

## 🕯️ Final Deployment Note

> *"If you deploy this publicly, you're creating a safe space for strangers. Handle that responsibility with care."*

Remember:
- Respect the privacy promise
- Don't add tracking
- Keep it free
- Maintain the compassionate philosophy

---

**Deployment is simple. Maintaining trust is the hard part.**

*Built with intention. Deployed with care.*