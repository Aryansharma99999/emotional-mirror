/* ====================================
   SANCTUARY - MAIN APPLICATION LOGIC
   Privacy-First Emotional Wellness App
   ==================================== */

// === STORAGE MANAGER === //
const StorageManager = {
    // Get data from localStorage
    get(key) {
        try {
            const data = localStorage.getItem(`sanctuary_${key}`);
            return data ? JSON.parse(data) : null;
        } catch (e) {
            console.error('Storage get error:', e);
            return null;
        }
    },

    // Save data to localStorage
    set(key, value) {
        try {
            localStorage.setItem(`sanctuary_${key}`, JSON.stringify(value));
            return true;
        } catch (e) {
            console.error('Storage set error:', e);
            return false;
        }
    },

    // Remove data from localStorage
    remove(key) {
        try {
            localStorage.removeItem(`sanctuary_${key}`);
            return true;
        } catch (e) {
            console.error('Storage remove error:', e);
            return false;
        }
    },

    // Clear all app data
    clearAll() {
        const keys = Object.keys(localStorage);
        keys.forEach(key => {
            if (key.startsWith('sanctuary_')) {
                localStorage.removeItem(key);
            }
        });
    }
};

// === APP STATE === //
let currentPage = 'home';
let currentTheme = 'midnight';
let currentMode = 'raw';
let selectedEmotionalState = null;

// === INITIALIZATION === //
document.addEventListener('DOMContentLoaded', () => {
    initializeApp();
    attachEventListeners();
    loadSavedTheme();
    loadAllEntries();
});

function initializeApp() {
    console.log('🕯️ Sanctuary initialized - Your safe space is ready');
}

// === THEME MANAGEMENT === //
function loadSavedTheme() {
    const savedTheme = StorageManager.get('theme') || 'midnight';
    setTheme(savedTheme);
}

function setTheme(themeName) {
    currentTheme = themeName;
    document.documentElement.setAttribute('data-theme', themeName);
    StorageManager.set('theme', themeName);
    
    // Update active theme button
    document.querySelectorAll('.theme-btn').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.theme === themeName);
    });
}

// === NAVIGATION === //
function goHome() {
    showPage('home');
}

function showPage(pageName) {
    // Hide all pages
    document.querySelectorAll('.page').forEach(page => {
        page.classList.remove('active');
    });
    
    // Show target page
    const targetPage = document.getElementById(`${pageName}Page`);
    if (targetPage) {
        targetPage.classList.add('active');
        currentPage = pageName;
    }
}

// === EVENT LISTENERS === //
function attachEventListeners() {
    // Theme selector
    document.querySelectorAll('.theme-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            setTheme(btn.dataset.theme);
        });
    });

    // Module cards navigation
    document.querySelectorAll('.module-card').forEach(card => {
        card.addEventListener('click', () => {
            const module = card.dataset.module;
            showPage(module);
            loadModuleData(module);
        });
    });

    // Panic button
    const panicBtn = document.getElementById('panicBtn');
    if (panicBtn) {
        panicBtn.addEventListener('click', handlePanicClose);
    }

    // Mode selector buttons
    document.querySelectorAll('.mode-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.mode-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            currentMode = btn.dataset.mode;
        });
    });

    // Emotion scale buttons
    document.querySelectorAll('.scale-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.scale-btn').forEach(b => b.classList.remove('selected'));
            btn.classList.add('selected');
            selectedEmotionalState = btn.dataset.state;
        });
    });

    // Word count for compress module
    const compressText = document.getElementById('compressText');
    if (compressText) {
        compressText.addEventListener('input', updateWordCount);
    }
}

// === DARK ROOM MODULE === //
function clearDarkRoom() {
    if (confirm('Clear this content? It will be gone forever.')) {
        document.getElementById('darkroomText').value = '';
    }
}

function saveDarkRoom() {
    const text = document.getElementById('darkroomText').value.trim();
    
    if (!text) {
        showNotification('Nothing to save', 'info');
        return;
    }

    const entry = {
        id: Date.now(),
        text: text,
        timestamp: Date.now(),
        autoDelete: document.getElementById('darkroomAutoDelete').checked
    };

    // Get existing entries
    const entries = StorageManager.get('darkroom_entries') || [];
    entries.unshift(entry);
    StorageManager.set('darkroom_entries', entries);

    // Clear textarea
    document.getElementById('darkroomText').value = '';
    
    showNotification('Held safely', 'success');
    loadDarkRoomEntries();
}

function loadDarkRoomEntries() {
    const entries = StorageManager.get('darkroom_entries') || [];
    const container = document.getElementById('darkroomEntries');
    
    if (entries.length === 0) {
        container.innerHTML = '';
        return;
    }

    container.innerHTML = '<h3>Held Thoughts</h3>';
    
    entries.forEach(entry => {
        const card = createEntryCard(entry, 'darkroom');
        container.appendChild(card);
    });
}

// === UNSENT MODULE === //
function clearUnsent() {
    document.getElementById('unsentText').value = '';
    document.getElementById('unsentRecipientName').value = '';
}

function saveUnsent() {
    const text = document.getElementById('unsentText').value.trim();
    const recipient = document.getElementById('unsentRecipient').value;
    const recipientName = document.getElementById('unsentRecipientName').value.trim();
    
    if (!text) {
        showNotification('Write something first', 'info');
        return;
    }

    const entry = {
        id: Date.now(),
        text: text,
        recipient: recipient,
        recipientName: recipientName,
        mode: currentMode,
        timestamp: Date.now()
    };

    const entries = StorageManager.get('unsent_entries') || [];
    entries.unshift(entry);
    StorageManager.set('unsent_entries', entries);

    clearUnsent();
    showNotification('Held. Never sent. Safe.', 'success');
    loadUnsentEntries();
}

function loadUnsentEntries() {
    const entries = StorageManager.get('unsent_entries') || [];
    const container = document.getElementById('unsentEntries');
    
    if (entries.length === 0) {
        container.innerHTML = '';
        return;
    }

    container.innerHTML = '<h3>Unsent Messages</h3>';
    
    entries.forEach(entry => {
        const card = createEntryCard(entry, 'unsent');
        container.appendChild(card);
    });
}

// === EMOTIONAL MIRROR MODULE === //
function getMirrorReflection() {
    const text = document.getElementById('mirrorText').value.trim();
    
    if (!text) {
        showNotification('Share something first', 'info');
        return;
    }

    showLoading('Reflecting...');

    // Simulate processing time for calm experience
    setTimeout(() => {
        const reflection = EmotionalEngine.generateReflection(text);
        displayMirrorReflection(reflection, text);
        hideLoading();
    }, 1500);
}

function displayMirrorReflection(reflection, originalText) {
    const container = document.getElementById('mirrorResponse');
    
    container.innerHTML = `
        <div class="response-text">
            <p style="margin-bottom: 20px;">${reflection.reflection}</p>
            <p style="margin-bottom: 20px;">${reflection.emotionName}</p>
            <p>${reflection.presence}</p>
        </div>
        <div class="response-emotions">
            ${reflection.detectedEmotions.map(e => `<span class="emotion-tag">${e}</span>`).join('')}
        </div>
        <div class="response-actions">
            <button class="secondary-btn" onclick="saveMirrorReflection('${btoa(originalText)}', '${btoa(JSON.stringify(reflection))}')">
                <i class="fas fa-save"></i> Hold This Reflection
            </button>
            <button class="secondary-btn" onclick="clearMirrorResponse()">
                <i class="fas fa-redo"></i> Try Again
            </button>
        </div>
    `;
    
    container.classList.add('active');
}

function saveMirrorReflection(encodedText, encodedReflection) {
    const text = atob(encodedText);
    const reflection = JSON.parse(atob(encodedReflection));
    
    const entry = {
        id: Date.now(),
        text: text,
        reflection: reflection,
        timestamp: Date.now()
    };

    const entries = StorageManager.get('mirror_entries') || [];
    entries.unshift(entry);
    StorageManager.set('mirror_entries', entries);

    showNotification('Reflection saved', 'success');
    loadMirrorEntries();
}

function clearMirrorResponse() {
    document.getElementById('mirrorResponse').classList.remove('active');
    document.getElementById('mirrorText').value = '';
}

function loadMirrorEntries() {
    const entries = StorageManager.get('mirror_entries') || [];
    const container = document.getElementById('mirrorEntries');
    
    if (entries.length === 0) {
        container.innerHTML = '';
        return;
    }

    container.innerHTML = '<h3>Past Reflections</h3>';
    
    entries.forEach(entry => {
        const card = createEntryCard(entry, 'mirror');
        container.appendChild(card);
    });
}

// === CLARITY MODULE === //
function getClarityInsight() {
    const text = document.getElementById('clarityText').value.trim();
    
    if (!text) {
        showNotification('Pour out the noise first', 'info');
        return;
    }

    showLoading('Finding the signal...');

    setTimeout(() => {
        const clarity = EmotionalEngine.generateClarity(text);
        displayClarityInsight(clarity, text);
        hideLoading();
    }, 2000);
}

function displayClarityInsight(clarity, originalText) {
    const container = document.getElementById('clarityResponse');
    
    container.innerHTML = `
        <div class="response-text">
            <h3 style="color: var(--accent-primary); margin-bottom: 20px;">The Core</h3>
            <p style="margin-bottom: 20px; font-size: 1.15rem;">${clarity.coreInsight}</p>
            <h4 style="color: var(--text-secondary); margin-bottom: 12px; font-size: 1rem;">What This Often Needs</h4>
            <p>${clarity.actionable}</p>
        </div>
        <div class="response-emotions">
            ${clarity.detectedEmotions.map(e => `<span class="emotion-tag">${e}</span>`).join('')}
        </div>
        <div class="response-actions">
            <button class="secondary-btn" onclick="saveClarityInsight('${btoa(originalText)}', '${btoa(JSON.stringify(clarity))}')">
                <i class="fas fa-save"></i> Hold This Insight
            </button>
            <button class="secondary-btn" onclick="clearClarityResponse()">
                <i class="fas fa-redo"></i> Try Again
            </button>
        </div>
    `;
    
    container.classList.add('active');
}

function saveClarityInsight(encodedText, encodedClarity) {
    const text = atob(encodedText);
    const clarity = JSON.parse(atob(encodedClarity));
    
    const entry = {
        id: Date.now(),
        text: text,
        clarity: clarity,
        timestamp: Date.now()
    };

    const entries = StorageManager.get('clarity_entries') || [];
    entries.unshift(entry);
    StorageManager.set('clarity_entries', entries);

    showNotification('Insight saved', 'success');
    loadClarityEntries();
}

function clearClarityResponse() {
    document.getElementById('clarityResponse').classList.remove('active');
    document.getElementById('clarityText').value = '';
}

function loadClarityEntries() {
    const entries = StorageManager.get('clarity_entries') || [];
    const container = document.getElementById('clarityEntries');
    
    if (entries.length === 0) {
        container.innerHTML = '';
        return;
    }

    container.innerHTML = '<h3>Past Insights</h3>';
    
    entries.forEach(entry => {
        const card = createEntryCard(entry, 'clarity');
        container.appendChild(card);
    });
}

// === EMOTIONAL TIDES MODULE === //
function saveCheckIn() {
    if (!selectedEmotionalState) {
        showNotification('Select how you\'re feeling', 'info');
        return;
    }

    const note = document.getElementById('tidesNote').value.trim();
    
    const checkIn = {
        id: Date.now(),
        state: selectedEmotionalState,
        note: note,
        timestamp: Date.now()
    };

    const checkIns = StorageManager.get('check_ins') || [];
    checkIns.push(checkIn);
    StorageManager.set('check_ins', checkIns);

    // Clear form
    document.querySelectorAll('.scale-btn').forEach(b => b.classList.remove('selected'));
    document.getElementById('tidesNote').value = '';
    selectedEmotionalState = null;

    showNotification('Moment recorded', 'success');
    loadTidesData();
}

function loadTidesData() {
    const checkIns = StorageManager.get('check_ins') || [];
    
    // Visualize data
    visualizeTides(checkIns);
    
    // Show insights
    if (checkIns.length >= 3) {
        const analysis = EmotionalEngine.analyzePattern(checkIns);
        displayTidesInsights(analysis);
    }
}

function visualizeTides(checkIns) {
    const container = document.getElementById('tidesChart');
    
    if (checkIns.length === 0) {
        container.innerHTML = '<p style="text-align: center; color: var(--text-muted);">Start tracking to see your patterns emerge</p>';
        return;
    }

    // Take last 30 check-ins
    const recentCheckIns = checkIns.slice(-30);
    
    const stateColors = {
        overwhelm: '#ef4444',
        heavy: '#f59e0b',
        neutral: '#6b7280',
        calm: '#10b981',
        hopeful: '#3b82f6'
    };

    const stateValues = {
        overwhelm: 1,
        heavy: 2,
        neutral: 3,
        calm: 4,
        hopeful: 5
    };

    // Create simple timeline visualization
    let html = '<div style="display: flex; gap: 8px; flex-wrap: wrap; justify-content: center; margin-bottom: 30px;">';
    
    recentCheckIns.forEach(checkIn => {
        const color = stateColors[checkIn.state];
        const date = new Date(checkIn.timestamp).toLocaleDateString();
        html += `
            <div style="width: 30px; height: 80px; background: ${color}; border-radius: 6px; opacity: 0.8; position: relative;" 
                 title="${checkIn.state} - ${date}">
            </div>
        `;
    });
    
    html += '</div>';
    
    // Add legend
    html += '<div style="display: flex; gap: 20px; justify-content: center; flex-wrap: wrap; font-size: 0.9rem;">';
    Object.entries(stateColors).forEach(([state, color]) => {
        html += `
            <div style="display: flex; align-items: center; gap: 8px;">
                <div style="width: 16px; height: 16px; background: ${color}; border-radius: 4px;"></div>
                <span style="color: var(--text-secondary);">${state}</span>
            </div>
        `;
    });
    html += '</div>';
    
    container.innerHTML = html;
}

function displayTidesInsights(analysis) {
    const container = document.getElementById('tidesInsights');
    
    const trendIcon = {
        positive: '📈',
        negative: '📉',
        neutral: '→'
    };

    container.innerHTML = `
        <h3 style="margin-bottom: 20px; color: var(--text-secondary);">Patterns</h3>
        <div class="insight-item">
            <h4>${trendIcon[analysis.trend]} Current Trend</h4>
            <p>${analysis.insight}</p>
        </div>
        <div class="insight-item">
            <h4>📊 Your Most Common State</h4>
            <p>You tend to feel <strong>${analysis.mostCommon}</strong> most often. This is information, not judgement.</p>
        </div>
        <div class="insight-item">
            <h4>📝 Check-ins Recorded</h4>
            <p>${analysis.checkInCount} moments tracked. Awareness is the first step.</p>
        </div>
    `;
}

// === COMPRESS & HOLD MODULE === //
function updateWordCount() {
    const text = document.getElementById('compressText').value.trim();
    const wordCount = text ? text.split(/\s+/).length : 0;
    document.getElementById('compressWordCount').textContent = `${wordCount} words`;
}

function compressEmotion() {
    const text = document.getElementById('compressText').value.trim();
    
    if (!text) {
        showNotification('Write something first', 'info');
        return;
    }

    showLoading('Compressing...');

    setTimeout(() => {
        const compressed = EmotionalEngine.compressEmotion(text);
        displayCompressedEmotion(compressed, text);
        hideLoading();
    }, 1800);
}

function displayCompressedEmotion(compressed, originalText) {
    const container = document.getElementById('compressResponse');
    
    container.innerHTML = `
        <div class="response-text">
            <h3 style="color: var(--accent-primary); margin-bottom: 20px;">Compressed Truth</h3>
            <p style="font-size: 1.2rem; line-height: 1.8; margin-bottom: 30px;">
                "${compressed.compressed}"
            </p>
            <div style="display: flex; gap: 20px; justify-content: center; margin-bottom: 20px;">
                <div style="text-align: center;">
                    <div style="font-size: 2rem; color: var(--accent-primary);">${compressed.original}</div>
                    <div style="font-size: 0.85rem; color: var(--text-muted);">original words</div>
                </div>
                <div style="text-align: center;">
                    <div style="font-size: 2rem; color: var(--accent-primary);">→</div>
                </div>
                <div style="text-align: center;">
                    <div style="font-size: 2rem; color: var(--accent-primary);">${compressed.compressed.split(/\s+/).length}</div>
                    <div style="font-size: 0.85rem; color: var(--text-muted);">compressed words</div>
                </div>
            </div>
            <p style="color: var(--text-muted); font-size: 0.9rem;">Core emotion: ${compressed.coreEmotion}</p>
        </div>
        <div class="response-actions">
            <button class="secondary-btn" onclick="saveCompressedEmotion('${btoa(originalText)}', '${btoa(JSON.stringify(compressed))}')">
                <i class="fas fa-save"></i> Hold This
            </button>
            <button class="secondary-btn" onclick="autoDeleteCompressed()">
                <i class="fas fa-trash"></i> Let It Dissolve
            </button>
            <button class="secondary-btn" onclick="clearCompressResponse()">
                <i class="fas fa-redo"></i> Try Again
            </button>
        </div>
    `;
    
    container.classList.add('active');
}

function saveCompressedEmotion(encodedText, encodedCompressed) {
    const text = atob(encodedText);
    const compressed = JSON.parse(atob(encodedCompressed));
    
    const entry = {
        id: Date.now(),
        originalText: text,
        compressed: compressed,
        timestamp: Date.now()
    };

    const entries = StorageManager.get('compress_entries') || [];
    entries.unshift(entry);
    StorageManager.set('compress_entries', entries);

    showNotification('Compression saved', 'success');
    loadCompressEntries();
}

function autoDeleteCompressed() {
    if (confirm('Let this dissolve? It will be gone.')) {
        clearCompressResponse();
        showNotification('Dissolved', 'success');
    }
}

function clearCompressResponse() {
    document.getElementById('compressResponse').classList.remove('active');
    document.getElementById('compressText').value = '';
    updateWordCount();
}

function loadCompressEntries() {
    const entries = StorageManager.get('compress_entries') || [];
    const container = document.getElementById('compressEntries');
    
    if (entries.length === 0) {
        container.innerHTML = '';
        return;
    }

    container.innerHTML = '<h3>Compressed Truths</h3>';
    
    entries.forEach(entry => {
        const card = createEntryCard(entry, 'compress');
        container.appendChild(card);
    });
}

// === ENTRY CARD CREATOR === //
function createEntryCard(entry, type) {
    const card = document.createElement('div');
    card.className = 'entry-card';
    card.dataset.id = entry.id;
    
    let content = '';
    
    if (type === 'darkroom') {
        content = `
            <div class="entry-header">
                <span class="entry-date">${EmotionalEngine.timeAgo(entry.timestamp)}</span>
                <div class="entry-actions">
                    <button class="entry-action-btn" onclick="deleteEntry(${entry.id}, 'darkroom')">Delete</button>
                </div>
            </div>
            <div class="entry-content">${truncateText(entry.text, 150)}</div>
        `;
    } else if (type === 'unsent') {
        const recipientLabel = entry.recipientName || entry.recipient.replace('-', ' ');
        content = `
            <div class="entry-header">
                <span class="entry-date">${EmotionalEngine.timeAgo(entry.timestamp)}</span>
                <div class="entry-actions">
                    <button class="entry-action-btn" onclick="deleteEntry(${entry.id}, 'unsent')">Delete</button>
                </div>
            </div>
            <div class="entry-meta" style="margin-bottom: 12px;">
                <strong>To:</strong> ${recipientLabel} <span style="margin-left: 12px; color: var(--text-muted);">Mode: ${entry.mode}</span>
            </div>
            <div class="entry-content">${truncateText(entry.text, 150)}</div>
        `;
    } else if (type === 'mirror') {
        content = `
            <div class="entry-header">
                <span class="entry-date">${EmotionalEngine.timeAgo(entry.timestamp)}</span>
                <div class="entry-actions">
                    <button class="entry-action-btn" onclick="deleteEntry(${entry.id}, 'mirror')">Delete</button>
                </div>
            </div>
            <div class="entry-content" style="margin-bottom: 12px;">${truncateText(entry.text, 100)}</div>
            <div class="entry-meta">
                <strong style="color: var(--accent-primary);">Reflection:</strong> ${entry.reflection.reflection}
            </div>
        `;
    } else if (type === 'clarity') {
        content = `
            <div class="entry-header">
                <span class="entry-date">${EmotionalEngine.timeAgo(entry.timestamp)}</span>
                <div class="entry-actions">
                    <button class="entry-action-btn" onclick="deleteEntry(${entry.id}, 'clarity')">Delete</button>
                </div>
            </div>
            <div class="entry-content" style="margin-bottom: 12px;">${truncateText(entry.text, 100)}</div>
            <div class="entry-meta">
                <strong style="color: var(--accent-primary);">Core:</strong> ${entry.clarity.coreInsight}
            </div>
        `;
    } else if (type === 'compress') {
        content = `
            <div class="entry-header">
                <span class="entry-date">${EmotionalEngine.timeAgo(entry.timestamp)}</span>
                <div class="entry-actions">
                    <button class="entry-action-btn" onclick="deleteEntry(${entry.id}, 'compress')">Delete</button>
                </div>
            </div>
            <div class="entry-meta" style="margin-bottom: 12px; font-style: italic;">
                "${entry.compressed.compressed}"
            </div>
            <div class="entry-content" style="font-size: 0.85rem;">${truncateText(entry.originalText, 100)}</div>
        `;
    }
    
    card.innerHTML = content;
    return card;
}

function truncateText(text, maxLength) {
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength) + '...';
}

// === DELETE ENTRY === //
function deleteEntry(id, type) {
    if (!confirm('Delete this entry? It cannot be recovered.')) {
        return;
    }

    const storageKey = `${type}_entries`;
    let entries = StorageManager.get(storageKey) || [];
    entries = entries.filter(e => e.id !== id);
    StorageManager.set(storageKey, entries);

    showNotification('Entry deleted', 'success');
    loadModuleData(type);
}

// === LOAD MODULE DATA === //
function loadModuleData(module) {
    if (module === 'darkroom') {
        loadDarkRoomEntries();
    } else if (module === 'unsent') {
        loadUnsentEntries();
    } else if (module === 'mirror') {
        loadMirrorEntries();
    } else if (module === 'clarity') {
        loadClarityEntries();
    } else if (module === 'tides') {
        loadTidesData();
    } else if (module === 'compress') {
        loadCompressEntries();
    }
}

function loadAllEntries() {
    loadDarkRoomEntries();
    loadUnsentEntries();
    loadMirrorEntries();
    loadClarityEntries();
    loadTidesData();
    loadCompressEntries();
}

// === PANIC CLOSE === //
function handlePanicClose() {
    const autoDelete = document.getElementById('darkroomAutoDelete').checked;
    
    if (autoDelete) {
        document.getElementById('darkroomText').value = '';
    }
    
    // Quickly navigate to a neutral page
    window.location.href = 'https://www.google.com';
}

// === LOADING OVERLAY === //
function showLoading(text = 'Processing...') {
    const overlay = document.getElementById('loadingOverlay');
    const loadingText = overlay.querySelector('.loading-text');
    loadingText.textContent = text;
    overlay.classList.add('active');
}

function hideLoading() {
    const overlay = document.getElementById('loadingOverlay');
    overlay.classList.remove('active');
}

// === NOTIFICATIONS === //
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        left: 50%;
        transform: translateX(-50%);
        background: var(--bg-card);
        color: var(--text-primary);
        padding: 16px 24px;
        border-radius: 10px;
        border: 1px solid var(--border-color);
        box-shadow: var(--shadow-lg);
        z-index: 10001;
        animation: slideDown 0.3s ease;
        font-size: 0.95rem;
    `;
    
    if (type === 'success') {
        notification.style.borderColor = 'var(--accent-primary)';
    }
    
    notification.textContent = message;
    document.body.appendChild(notification);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideUp 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Add CSS for notification animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideDown {
        from {
            opacity: 0;
            transform: translateX(-50%) translateY(-20px);
        }
        to {
            opacity: 1;
            transform: translateX(-50%) translateY(0);
        }
    }
    
    @keyframes slideUp {
        from {
            opacity: 1;
            transform: translateX(-50%) translateY(0);
        }
        to {
            opacity: 0;
            transform: translateX(-50%) translateY(-20px);
        }
    }
`;
document.head.appendChild(style);

// === KEYBOARD SHORTCUTS === //
document.addEventListener('keydown', (e) => {
    // Escape key to go home
    if (e.key === 'Escape' && currentPage !== 'home') {
        goHome();
    }
    
    // Ctrl/Cmd + S to save (prevent default browser save)
    if ((e.ctrlKey || e.metaKey) && e.key === 's') {
        e.preventDefault();
        // Trigger save for current module
        if (currentPage === 'darkroom') saveDarkRoom();
        else if (currentPage === 'unsent') saveUnsent();
    }
});

console.log('🕯️ Sanctuary is ready. Your safe space awaits.');