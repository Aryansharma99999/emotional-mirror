/* ====================================
   EMOTIONAL INTELLIGENCE ENGINE
   AI-Style Reflection & Pattern Recognition
   ==================================== */

const EmotionalEngine = {
    
    // === EMOTION KEYWORDS DATABASE === //
    emotionKeywords: {
        fear: ['afraid', 'scared', 'anxious', 'worried', 'terrified', 'panic', 'nervous', 'uneasy', 'frightened'],
        anger: ['angry', 'mad', 'furious', 'frustrated', 'irritated', 'enraged', 'bitter', 'resentful', 'hostile'],
        sadness: ['sad', 'depressed', 'down', 'miserable', 'hopeless', 'empty', 'numb', 'grief', 'heartbroken'],
        loneliness: ['lonely', 'alone', 'isolated', 'abandoned', 'disconnected', 'unseen', 'invisible', 'forgotten'],
        guilt: ['guilty', 'ashamed', 'regret', 'sorry', 'fault', 'blame', 'wrong', 'bad'],
        overwhelm: ['overwhelmed', 'exhausted', 'tired', 'drained', 'burned out', 'too much', 'can\'t cope'],
        confusion: ['confused', 'lost', 'uncertain', 'unclear', 'mixed up', 'don\'t know', 'chaos', 'fog'],
        hope: ['hope', 'hopeful', 'optimistic', 'possibility', 'maybe', 'better', 'light'],
        relief: ['relief', 'lighter', 'calm', 'peaceful', 'settled', 'okay', 'fine'],
        avoidance: ['avoiding', 'running', 'hiding', 'escaping', 'can\'t face', 'don\'t want to think']
    },

    // === REFLECTION TEMPLATES === //
    reflectionTemplates: {
        fear: [
            "You sound like you're carrying a lot of worry right now.",
            "There's a weight in this — fear of what might happen.",
            "It feels like uncertainty is pressing down on you."
        ],
        anger: [
            "You sound tired of being unheard.",
            "This feels like frustration that's been building.",
            "There's a rawness here — anger that needs space."
        ],
        sadness: [
            "You sound heavy right now.",
            "This feels like grief — the kind that sits quietly.",
            "There's a deep ache in this."
        ],
        loneliness: [
            "You sound like you're carrying this alone.",
            "This feels like emotional loneliness — being surrounded but unseen.",
            "There's an isolation in this that runs deep."
        ],
        guilt: [
            "You sound like you're holding yourself responsible.",
            "This feels like guilt — the kind that whispers 'you should have known better.'",
            "There's a weight of self-blame here."
        ],
        overwhelm: [
            "You sound exhausted — not just physically, but emotionally.",
            "This feels like too much to hold at once.",
            "There's a heaviness here that's become familiar."
        ],
        confusion: [
            "You sound like you're navigating fog.",
            "This feels unclear — like pieces that don't quite fit.",
            "There's a searching quality here, looking for clarity."
        ],
        hope: [
            "You sound like you're reaching for something.",
            "There's a quiet hope in this — tentative but real.",
            "This feels like possibility beginning to emerge."
        ]
    },

    // === PRESENCE STATEMENTS === //
    presenceStatements: [
        "That's heavy to carry alone.",
        "That takes courage to name.",
        "That's real and valid.",
        "You don't have to fix this right now.",
        "It makes sense you'd feel this way.",
        "That's a lot to hold.",
        "Your feelings don't need permission.",
        "This deserves space."
    ],

    // === DETECT DOMINANT EMOTIONS === //
    detectEmotions(text) {
        const lowercaseText = text.toLowerCase();
        const detectedEmotions = [];
        
        for (const [emotion, keywords] of Object.entries(this.emotionKeywords)) {
            const score = keywords.reduce((count, keyword) => {
                return count + (lowercaseText.split(keyword).length - 1);
            }, 0);
            
            if (score > 0) {
                detectedEmotions.push({ emotion, score });
            }
        }
        
        // Sort by score
        detectedEmotions.sort((a, b) => b.score - a.score);
        
        return detectedEmotions.length > 0 
            ? detectedEmotions.slice(0, 3) 
            : [{ emotion: 'overwhelm', score: 1 }];
    },

    // === GENERATE MIRROR REFLECTION === //
    generateReflection(text) {
        const emotions = this.detectEmotions(text);
        const primaryEmotion = emotions[0].emotion;
        
        // Get reflection template
        const templates = this.reflectionTemplates[primaryEmotion] || this.reflectionTemplates.overwhelm;
        const reflection = this.randomChoice(templates);
        
        // Get emotion name
        const emotionName = this.getEmotionName(emotions);
        
        // Get presence statement
        const presence = this.randomChoice(this.presenceStatements);
        
        return {
            reflection,
            emotionName,
            presence,
            detectedEmotions: emotions.map(e => e.emotion)
        };
    },

    // === GET EMOTION NAME === //
    getEmotionName(emotions) {
        if (emotions.length === 1) {
            return `This feels like ${emotions[0].emotion}.`;
        } else if (emotions.length === 2) {
            return `This feels like ${emotions[0].emotion} mixed with ${emotions[1].emotion}.`;
        } else {
            return `This feels like a mix of ${emotions[0].emotion}, ${emotions[1].emotion}, and ${emotions[2].emotion}.`;
        }
    },

    // === GENERATE CLARITY INSIGHT === //
    generateClarity(text) {
        const emotions = this.detectEmotions(text);
        const primaryEmotion = emotions[0].emotion;
        
        const coreInsights = {
            fear: "At the core, this seems to be about feeling unsafe with uncertainty.",
            anger: "At the core, this seems to be about feeling unheard or unseen.",
            sadness: "At the core, this seems to be about loss — of something or someone important.",
            loneliness: "At the core, this seems to be about disconnection — from yourself or others.",
            guilt: "At the core, this seems to be about wanting to have done things differently.",
            overwhelm: "At the core, this seems to be about carrying more than one person should.",
            confusion: "At the core, this seems to be about needing clarity that isn't coming.",
            hope: "At the core, this seems to be about wanting to believe things can change."
        };
        
        const insight = coreInsights[primaryEmotion] || coreInsights.overwhelm;
        
        const actionable = this.getActionableInsight(primaryEmotion);
        
        return {
            coreInsight: insight,
            actionable,
            detectedEmotions: emotions.map(e => e.emotion)
        };
    },

    // === GET ACTIONABLE INSIGHT === //
    getActionableInsight(emotion) {
        const insights = {
            fear: "Fear often needs: grounding in the present, naming what's real vs. imagined.",
            anger: "Anger often needs: acknowledgment, and boundaries that honor your needs.",
            sadness: "Sadness often needs: permission to be felt, without rushing to fix it.",
            loneliness: "Loneliness often needs: connection that feels genuine, not just physical presence.",
            guilt: "Guilt often needs: self-compassion and the understanding that you did the best you could.",
            overwhelm: "Overwhelm often needs: permission to let something go, even temporarily.",
            confusion: "Confusion often needs: small steps forward, not perfect clarity all at once.",
            hope: "Hope often needs: tiny actions that align with what you want to move toward."
        };
        
        return insights[emotion] || insights.overwhelm;
    },

    // === COMPRESS EMOTION === //
    compressEmotion(text) {
        const emotions = this.detectEmotions(text);
        const primaryEmotion = emotions[0].emotion;
        
        // Extract key themes
        const wordCount = text.split(/\s+/).length;
        
        // Generate compression based on emotion
        const compressions = {
            fear: [
                "I'm afraid of what I can't control.",
                "Uncertainty feels unbearable right now.",
                "I'm scared and trying to hold it together."
            ],
            anger: [
                "I'm angry and tired of not being heard.",
                "This frustration has been building for too long.",
                "I deserve better than this."
            ],
            sadness: [
                "I'm grieving something I didn't get to keep.",
                "The emptiness is heavy and real.",
                "I miss what used to be."
            ],
            loneliness: [
                "I feel invisible, even when I'm not alone.",
                "This loneliness goes deeper than just being by myself.",
                "I'm surrounded but still unseen."
            ],
            guilt: [
                "I'm carrying blame that might not all be mine.",
                "I wish I had known better then.",
                "This guilt feels too heavy to keep holding."
            ],
            overwhelm: [
                "I'm carrying too much and running on empty.",
                "Everything feels like too much right now.",
                "I need space but don't know how to take it."
            ]
        };
        
        const compressed = this.randomChoice(compressions[primaryEmotion] || compressions.overwhelm);
        
        return {
            original: wordCount,
            compressed: compressed,
            reduction: Math.round((1 - (compressed.split(/\s+/).length / wordCount)) * 100),
            coreEmotion: primaryEmotion
        };
    },

    // === ANALYZE EMOTIONAL PATTERN === //
    analyzePattern(checkIns) {
        if (checkIns.length < 3) {
            return {
                insight: "Keep tracking. Patterns emerge over time.",
                trend: "neutral"
            };
        }

        // Get recent trend (last 7 days)
        const recentCheckIns = checkIns.slice(-7);
        const states = ['overwhelm', 'heavy', 'neutral', 'calm', 'hopeful'];
        const stateValues = { overwhelm: 1, heavy: 2, neutral: 3, calm: 4, hopeful: 5 };
        
        const avgRecent = recentCheckIns.reduce((sum, c) => sum + stateValues[c.state], 0) / recentCheckIns.length;
        const avgOverall = checkIns.reduce((sum, c) => sum + stateValues[c.state], 0) / checkIns.length;
        
        let insight = "";
        let trend = "neutral";
        
        if (avgRecent > avgOverall + 0.5) {
            insight = "You've been moving toward more calm recently. That's real progress.";
            trend = "positive";
        } else if (avgRecent < avgOverall - 0.5) {
            insight = "Things have felt heavier lately. That's worth noticing gently.";
            trend = "negative";
        } else {
            insight = "Your emotional state has been fairly consistent. That stability matters.";
            trend = "neutral";
        }
        
        // Check for patterns
        const mostCommon = this.getMostCommonState(checkIns);
        
        return {
            insight,
            trend,
            mostCommon,
            checkInCount: checkIns.length
        };
    },

    // === GET MOST COMMON STATE === //
    getMostCommonState(checkIns) {
        const counts = {};
        checkIns.forEach(c => {
            counts[c.state] = (counts[c.state] || 0) + 1;
        });
        
        const sorted = Object.entries(counts).sort((a, b) => b[1] - a[1]);
        return sorted[0] ? sorted[0][0] : 'neutral';
    },

    // === UTILITY: RANDOM CHOICE === //
    randomChoice(array) {
        return array[Math.floor(Math.random() * array.length)];
    },

    // === FORMAT DATE === //
    formatDate(timestamp) {
        const date = new Date(timestamp);
        const options = { 
            year: 'numeric', 
            month: 'short', 
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        };
        return date.toLocaleDateString('en-US', options);
    },

    // === TIME AGO === //
    timeAgo(timestamp) {
        const now = Date.now();
        const diff = now - timestamp;
        
        const minutes = Math.floor(diff / 60000);
        const hours = Math.floor(diff / 3600000);
        const days = Math.floor(diff / 86400000);
        
        if (minutes < 1) return 'just now';
        if (minutes < 60) return `${minutes}m ago`;
        if (hours < 24) return `${hours}h ago`;
        if (days < 7) return `${days}d ago`;
        return this.formatDate(timestamp);
    }
};

// === EXPORT FOR USE === //
if (typeof module !== 'undefined' && module.exports) {
    module.exports = EmotionalEngine;
}